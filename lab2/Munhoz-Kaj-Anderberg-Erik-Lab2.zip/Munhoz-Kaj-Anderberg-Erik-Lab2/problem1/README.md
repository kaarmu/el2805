# Problem 1

All results used in the report is saved under `solution/`. The main solution
is the network saved under `solution/2layer64_ep400_decay05`. These files are
also the same you will find in the root of `problem1`.

## Authors

Kaj Munhoz Arfvidsson,  19980213-4032
Erik Anderberg,         19960806-7857

